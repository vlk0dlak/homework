<?php

namespace App\Model;

use Nette\Utils\Finder;

class FileSystem
{

   /**
    * config settings
    *
    * @var type
    */
   private $config;

   /**
    * loading config
    *
    * @param type $parameters
    */
   public function __construct($parameters)
   {
      $this->config = $parameters;
   }

   public function writingToFile(string $filename, $data)
   {
      file_put_contents($this->config['newsletterdata'] . $filename, json_encode($data));
   }

   public function listFiles()
   {
      return Finder::findFiles('*.*')->from($this->config['newsletterdata']);
   }

   public function readFile(string $filename)
   {
      return file_get_contents($filename);
   }

}
