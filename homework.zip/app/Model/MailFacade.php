<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Model;

use Nette\Mail\SendmailMailer;

/**
 * Description of MailFacade
 *
 * @author vladimir
 */
class MailFacade
{

   /**
    * config settings
    *
    * @var type
    */
   public $config;

   /**
    * loading config
    *
    * @param type $parameters
    */
   public function __construct($parameters)
   {
      $this->config = $parameters;
   }

   public function sendmail(string $addTo, string $setHtmlBody)
   {
      $latte	 = new \Latte\Engine();
      $params	 = [
	  'orderId' => 123,
      ];

      $mail = new \Nette\Mail\Message();
      $mail->setFrom('NewsLetter <' . $this->config['newslettermailmail'] . '>')
	      ->addTo($addTo)
	      ->setSubject('News Letter s jidlem')
	      ->setHtmlBody(
		      $latte->renderToString($this->config['appDir'] . '/Presenters/templates/homepage/mailnewsletter.latte', $params),
			       '/path/to/images'
      );
   }

}
