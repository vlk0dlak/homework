<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Model;

/**
 * Description of ZomatoFacade
 *
 * @author vladimir
 */
class ZomatoFacade
{

   /**
    * config settings
    *
    * @var type
    */
   private $config;

   /**
    * loading config
    *
    * @param type $parameters
    */
   public function __construct($parameters)
   {
      $this->config = $parameters;
   }

   /**
    * send the request about menu rest id
    *
    * @return type
    */
   public function loadDataMenu(string $restid): array
   {
      $curl = curl_init();

      curl_setopt_array($curl, array(
	  CURLOPT_RETURNTRANSFER	 => true,
	  CURLOPT_HTTPHEADER	 => ['Accept: application/json', 'user-key: ' . $this->config['config_zomato']['user_key']],
	  CURLOPT_URL		 => 'https://developers.zomato.com/api/v2.1/dailymenu?res_id=' . $restid,
      ));

      $resp = curl_exec($curl);

      // wrong comunication with server
      if (!curl_exec($curl))
      {
	 $resp = array('status' => 'error', 'erinfo' => 'loadDataMenu1: ' . curl_error($curl), 'erno' => curl_errno($curl));
	 return $resp;
      }

      curl_close($curl);

      $jsonZomato = json_decode($resp, true);

      // wrong ask to server or other errors
      if ($jsonZomato['status'] == 'Forbidden')
      {
	 $resp = array('status' => 'error', 'erinfo' => 'loadDataMenu2: ' . $jsonZomato['status'], 'erno' => $jsonZomato['code']);
	 return $resp;
      }

      $rest['menu']['status'] = 'success';
      return $jsonZomato;
   }

   /**
    * send a request for info to the restaurant
    *
    * @return type
    */
   public function loadDataRest(string $restid): array
   {
      $curl = curl_init();

      curl_setopt_array($curl, array(
	  CURLOPT_RETURNTRANSFER	 => true,
	  CURLOPT_HTTPHEADER	 => ['Accept: application/json', 'user-key: ' . $this->config['config_zomato']['user_key']],
	  CURLOPT_URL		 => 'https://developers.zomato.com/api/v2.1/restaurant?res_id=' . $restid,
      ));

      $rest = curl_exec($curl);

      // wrong comunication with server
      if (!curl_exec($curl))
      {
	 $rest = array('status' => 'error', 'erinfo' => 'loadDataRest1: ' . curl_error($curl), 'erno' => curl_errno($curl));
	 return $rest;
      }

      curl_close($curl);

      $jsonZomato = json_decode($rest, true);

      $rest = array('restname' => $jsonZomato['name'], 'restid' => $jsonZomato['id']);

      $rest['status'] = 'success';
      return $rest;
   }

   /**
    * load all data about rest and menu
    *
    * @return type
    */
   public function loadAll()
   {

      foreach ($this->config['config_zomato']['restaurace'] as $key => $value)
      {
	 // load info about rest
	 $loaddata = $this->loadDataRest($value);

	 if ($loaddata['status'] == 'error')
	 {
	    return $loaddata;
	 };
	 $rest [$key]['info'] = $loaddata;

	 // load menu
	 $loaddata = $this->loadDataMenu($value);
	 if ($loaddata['status'] == 'error')
	 {
	    return $loaddata;
	 };
	 $rest [$key]['menu'] = $loaddata;
      }

      $rest['status'] = 'success';
      return $rest;
   }

}
