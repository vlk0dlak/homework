<?php

declare(strict_types=1);

namespace App\Presenters;

use Nette\Application\UI\Form;

final class HomepagePresenter extends BasePresenter
{

   public function renderAddletter()
   {

   }

   protected function createComponentLetterForm()
   {
      $form			 = new Form;
      $form->addText('name', 'Jmeno:');
      $form->addEmail('mail', 'Mail:')
	      ->setHtmlAttribute('placeholder', 'Prosím vyplňte mail')
	      ->setRequired('Zadejte e-mailovou adresu');
      $form->addSubmit('send', 'Registrovat');
      $form->onSuccess[]	 = [$this, 'formSucceeded'];
      return $form;
   }

   public function formSucceeded(Form $form, $data): void
   {
      // TODO- insert to database or other work steps with user data
      $this->flashMessage('Byl jste úspěšně registrován.');
      $this->redirect('Homepage:');
   }

   public function renderDefault()
   {

      $restaurace = $this->zomatoFacade->loadAll();
      if ($restaurace['status'] == 'error')
      {
	 $this->flashMessage($restaurace['erno'] . ' ' . $restaurace['erinfo'], 'error');
	 $this->redirect('Homepage:error');
      };

      $this->template->mydata = $restaurace;
   }

   function renderError()
   {

   }

}
