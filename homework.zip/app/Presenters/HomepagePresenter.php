<?php

declare(strict_types=1);

namespace App\Presenters;

use Nette\Application\UI\Form;

final class HomepagePresenter extends BasePresenter
{

   public function actionSendnewsletter()
   {
      /*
        name: 'vilik'
        mail: 'vlkodlak@centrum.sk'
        restaurant: array
        0 => 16507624
        1 => 16774318
       */

      // finding all register files
      foreach ($this->fileSystem->listFiles() as $key => $file)
      {
	 $htmlmailbody	 = '';
	 $aaa		 = json_decode($this->fileSystem->readFile($key));

	 // read ID restaurace adn loading menu
	 foreach ($aaa->restaurant as $key2 => $value2)
	 {
	    // prepare menu
	    $bbb		 = $this->zomatoFacade->loadDataRest($value2);
	    $htmlmailbody	 = $bbb['restname'] . '<hr>';
	    bdump($this->zomatoFacade->loadDataMenu($value2));
	    bdump($this->mailFacade->createmail());
	 }




	 //bdump($this->mailFacade->sendmail($key['mail'], 'aaaa'));
      };
   }

   protected function createComponentLetterForm()
   {
      $form			 = new Form;
      $form->addText('name', 'Name:')
	      ->addRule(Form::FILLED, 'Please insert your name')
	      ->setHtmlAttribute('placeholder', 'Please insert your name');
      $form->addEmail('mail', 'Mail:')
	      ->setHtmlAttribute('placeholder', 'Please insert your mail')
	      ->addRule($form::EMAIL, 'Please insert valid email')
	      ->setRequired('Please insert your mail');
      $form->addCheckboxList('restaurant', 'ID Restaurant:', $this->zomatoFacade->listrestа());
      $form->addSubmit('send', 'Registrovat');
      $form->onSuccess[]	 = [$this, 'formSucceeded'];
      return $form;
   }

   public function formSucceeded(Form $form, $data): void
   {
      $this->fileSystem->writingToFile($data['mail'], $data);

      $this->flashMessage('You have been successfully registered.');
      $this->redirect('Homepage:');
   }

   public function renderDefault()
   {
      $restaurace = $this->zomatoFacade->loadAll();
      if ($restaurace['status'] == 'error')
      {
	 $this->flashMessage($restaurace['erno'] . ' ' . $restaurace['erinfo'], 'error');
	 $this->redirect('Homepage:error');
      };

      $this->template->mydata = $restaurace;
   }

   function renderError()
   {

   }

}
