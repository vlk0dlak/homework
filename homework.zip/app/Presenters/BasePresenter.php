<?php

declare(strict_types=1);

namespace App\Presenters;

use Nette;

/**
 * Base presenter for all application presenters.
 */
abstract class BasePresenter extends Nette\Application\UI\Presenter
{

   /** @var \App\Model\ZomatoFacade @inject */
   public $zomatoFacade;

   /** @var \App\Model\MailFacade @inject */
   public $mailFacade;

   /** @var \App\Model\FileSystem @inject */
   public $fileSystem;

}
